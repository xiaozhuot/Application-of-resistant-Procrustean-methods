library(gllvm)
library(vegan)
library("FactoMineR")
library("factoextra")
library(fBasics)#take trace
library(combinat)#permutation
library("readxl")
library(gtools) #for combination()
library(expm)
library(IMIFA)
library(ggplot2)
library(plotrix)
library(Cairo)
library(ape)
library(cowplot)
library(ggrepel)
library(patchwork)

source("resistant_codes_LMS_LTS.txt")
source("test of permutation.txt")


anth_dis = read.csv("Yam_anth.csv",header = FALSE)/100
gene_dis = read.csv("Yam_gene.csv",header = FALSE)/100
geo_dis = read.csv("Yam_geo.csv",header = FALSE)/100
PCoA_anth = pcoa(anth_dis)
anth_data = PCoA_anth$vectors[,1:2]
PCoA_gene = pcoa(gene_dis)
gene_data = PCoA_gene$vectors[,1:2] 
PCoA_geo = pcoa(geo_dis)
geo_data = PCoA_geo$vectors[,1:2]

anth_var_exp <- 100 * PCoA_anth$values$Relative_eig[1:2]
gene_var_exp <- 100 * PCoA_gene$values$Relative_eig[1:2]
geo_var_exp  <- 100 * PCoA_geo$values$Relative_eig[1:2]

######################################################
# Assuming 'anth_data' is a matrix/dataframe with columns PC1 and PC2
# and row names are village IDs

# Convert to dataframe for ggplot
x_labels = c("03AB","03C","03D","03KP","03LMN","03RS","03T",
             "08E","08F","08K","08XY","11ABC","11D","11HI","11LQ","11S","11T","11U","11X")

gene_df <- data.frame(PC1 = gene_data[,1], PC2 = gene_data[,2], village = x_labels)
anth_df <- data.frame(PC1 = anth_data[,1], PC2 = anth_data[,2], village = x_labels)
geo_df  <- data.frame(PC1 = geo_data[,1], PC2 = geo_data[,2], village = x_labels)


pcoa_plot <- function(df, title,var_exp,reflect_x = FALSE, reflect_y = FALSE) {
  
  if(reflect_x) df$PC1 <- -df$PC1
  if(reflect_y) df$PC2 <- -df$PC2
  
  ggplot(df, aes(x = PC1, y = PC2)) +
    geom_point(size = 2.5) +
    geom_text_repel(aes(label = village), size = 3.5, show.legend = FALSE) +
    geom_hline(yintercept = 0, linetype = "dashed", color = "grey50") +
    geom_vline(xintercept = 0, linetype = "dashed", color = "grey50") +
    #coord_equal() +  #1 unit on the x-axis = 1 unit on the y-axis
    #coord_fixed() +
    theme_classic() +  # clean background
    labs(title = title,
         x = paste0("PCoA1 (", round(var_exp[1],1), "%)"),
         y = paste0("PCoA2 (", round(var_exp[2],1), "%)")) +
    theme(legend.position = "none",
    axis.title.y = element_text(size=14,margin = margin(r = 8)),
    axis.title.x = element_text(size=14,margin = margin(t = 10)))  # hide legend for clean figure
}

# Create individual plots
p1 <- pcoa_plot(gene_df, "SFA",gene_var_exp)
p2 <- pcoa_plot(anth_df, "Anthropometric",anth_var_exp,reflect_x = TRUE, reflect_y = TRUE)
p3 <- pcoa_plot(geo_df, "Geographic",geo_var_exp)

# Combine into one figure side by side
#combined_plot <- plot_grid(p1, p2, p3, nrow = 1, labels = c("A", "B", "C"))

combined_plot <- p1 / p2 / p3

# Display the combined plot
print(combined_plot)




##############################################################
P_mat = as.matrix(gene_data)
Q_mat = as.matrix(geo_data)
 
 
# P_mat = as.matrix(anth_data)
# Q_mat = as.matrix(geo_data)

  
# P_mat = as.matrix(gene_data)
# Q_mat = as.matrix(anth_data)





##procrustes##
result_proc = Procrustes_fun(P_mat,Q_mat)
procrustes_obj = result_proc$s
res_procrustes = Procrustes_permute(P_mat,Q_mat,999,procrustes_obj)
sum(res_procrustes$converge_vec)
res_procrustes$p_value

vector_1 = rep(1,dim(P_mat)[1])
result_procrustes_residual = 
  Q_mat - result_proc$scal*(P_mat)%*%(result_proc$rot)-vector_1%*%t(result_proc$trans_P)
# mean_mad_procrustes = mean(apply(result_procrustes_residual,2,mad,constant=1))
# sd_procrustes_residual = result_procrustes_residual/mean_mad_procrustes
# sd_procrustes_residual_dis = sqrt(rowSums(sd_procrustes_residual*sd_procrustes_residual))
# barplot(sd_procrustes_residual_dis,main="Procrustes",las = 2, cex.names = 0.65)

procrustes_residual_dis = sqrt(rowSums(result_procrustes_residual*result_procrustes_residual))
barplot(procrustes_residual_dis,las = 2,main="Procrustes",cex.names = 0.65)

################
result_ILMS= LMS_LTS_estimator(P_mat,Q_mat,0,s_l_LMS,s_u_LMS)
#result_ILMS= LMS_LTS_estimator(P_mat,Q_mat,10000,s_l_LMS,s_u_LMS)used for permutation
ILMS_obj = result_ILMS$s
res_ILMS = ILMS_permute(P_mat,Q_mat,999,ILMS_obj)
ILMS_p_value = res_ILMS$p_value

vector_1 = rep(1,dim(P_mat)[1])
result_ILMS_residual =
  Q_mat - result_ILMS$scal*(P_mat)%*%(result_ILMS$rot)-vector_1%*%t(result_ILMS$trans_P)
result_ILMS_residual_dis = sqrt(rowSums(result_ILMS_residual*result_ILMS_residual))
barplot(result_ILMS_residual_dis,las = 2,main="ILMS",cex.names = 0.65)
save(result_ILMS_residual_dis, file = "gene and geo ILMS residuals.RData")
save(result_ILMS_residual_dis, file = "anth and geo ILMS residuals.RData")
save(result_ILMS_residual_dis, file = "gene and anth ILMS residuals.RData")



#########residual plot add median and quartiles

x_labels = c("03AB","03C","03D","03KP","03LMN","03RS","03T",
      "08E","08F","08K","08XY","11ABC","11D","11HI","11LQ","11S","11T","11U","11X")

#gene and geo
# colors_1 = ifelse(x_labels %in% c("08E","08F"), "darksalmon", "darkgray")
# 
# colors_2 = ifelse(x_labels %in% c("08F"), "darksalmon", "darkgray")

par(mfrow=c(2,1),mar=c(4,2,1,1),oma=c(0,3,1,3),cex.axis = 1.3)
outer = FALSE
line = -0.01
cex = 1.5
adj  = 0.001
barplot(result_ILMS_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = " ",
        ylab = " ",
        xaxt = "s",
        names.arg = FALSE,
        #col = colors_2,
        horiz = FALSE
)
abline(h = quantile(result_ILMS_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(result_ILMS_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(result_ILMS_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="ILMS",cex.main=cex,col="black",font=2,line=line)

bp_PA =barplot(procrustes_residual_dis,cex.names = 1.3,
               main = " ",
               xlab = "",
               ylab = " ",
               xaxt = "s",
               names.arg = FALSE,
               las =2,
               #col = colors_1,
               space = 0.5,
               horiz = FALSE)
abline(h = quantile(procrustes_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(procrustes_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(procrustes_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="PA",cex.main=cex,col="black",font=2,line=line)
text(x = bp_PA, y = par("usr")[3] - 0.1,  # just below the bars
     labels = x_labels, srt = 45, xpd = TRUE,
     adj = 1, cex = 1)





##########################
##Anthro vs. geo
# colors_1 = ifelse(x_labels %in% c("03KP","03RS","03T"), "darksalmon", "darkgray") 
# colors_2 = ifelse(x_labels %in% c("08E","08F"), "darksalmon", "darkgray") 

par(mfrow=c(1,3),mar=c(6.5,3,1,1),oma=c(0.5,3,1.5,3),cex.axis = 2,las=2)
outer = FALSE
line = -0.5
cex = 2
adj  = 0.02
barplot(procrustes_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = "",
        ylab = " ",
        xaxt = "s",
        names.arg = x_labels,
        las =2,
        #col = colors_2,
        space = 0.5,
        horiz = FALSE)
abline(h = quantile(procrustes_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(procrustes_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(procrustes_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="PA",cex.main=cex,col="black",font=2,line=line)
# barplot(result_S_residual_dis,cex.names = 1.3,
#         main = " ",
#         xlab = " ",
#         ylab = " ",
#         xaxt = "s",
#         names.arg = names(result_S_residual_dis),
#         #col = colors_1,
#         space = 0.5,
#         horiz = FALSE)
# abline(h = quantile(result_S_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
# abline(h = quantile(result_S_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
# abline(h = quantile(result_S_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
# title(outer=outer,adj=adj,main="S",cex.main=cex,col="black",font=2,line=line)
barplot(result_LMS_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = " ",
        ylab = " ",
        xaxt = "s",
        names.arg = x_labels,
        col = colors_1,
        horiz = FALSE
)
abline(h = quantile(result_LMS_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=2)
abline(h = quantile(result_LMS_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=1)
abline(h = quantile(result_LMS_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=1)
title(outer=outer,adj=adj,main="LMS",cex.main=cex,col="black",font=2,line=line)
barplot(result_LTS_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = " ",
        ylab = " ",
        xaxt = "s",
        names.arg = x_labels,
        col = colors_2,
        horiz = FALSE
)
abline(h = quantile(result_LTS_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=2)
abline(h = quantile(result_LTS_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=1)
abline(h = quantile(result_LTS_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=1)
title(outer=outer,adj=adj,main="LTS",cex.main=cex,col="black",font=2,line=line)



##gene vs. anthro
colors_1 = ifelse(x_labels %in% c("08F"), "darksalmon", "darkgray") 
colors_2 = ifelse(x_labels %in% c("03KP","03RS","08E","08F"), "darksalmon", "darkgray") 
colors_3 = ifelse(x_labels %in% c("03KP","03RS","08E","08F","03T"), "darksalmon", "darkgray") 

par(mfrow=c(1,3),mar=c(11.5,5,1,2),oma=c(0.5,3,1.5,3),cex.axis = 2,las=2)
outer = FALSE
line = -0.5
cex = 2
adj  = 0.02
barplot(procrustes_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = "",
        ylab = " ",
        xaxt = "s",
        names.arg = x_labels,
        las =2,
        col = colors_1,
        space = 0.5,
        horiz = FALSE)
abline(h = quantile(procrustes_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(procrustes_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(procrustes_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="PA",cex.main=cex,col="black",font=2,line=line)
# barplot(result_S_residual_dis,cex.names = 1.3,
#         main = " ",
#         xlab = " ",
#         ylab = " ",
#         xaxt = "s",
#         names.arg = names(result_S_residual_dis),
#         #col = colors_1,
#         space = 0.5,
#         horiz = FALSE)
# abline(h = quantile(result_S_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
# abline(h = quantile(result_S_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
# abline(h = quantile(result_S_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
# title(outer=outer,adj=adj,main="S",cex.main=cex,col="black",font=2,line=line)
barplot(result_LMS_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = " ",
        ylab = " ",
        xaxt = "s",
        names.arg = x_labels,
        col = colors_2,
        horiz = FALSE
)
abline(h = quantile(result_LMS_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=2)
abline(h = quantile(result_LMS_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=1)
abline(h = quantile(result_LMS_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=1)
title(outer=outer,adj=adj,main="LMS",cex.main=cex,col="black",font=2,line=line)
barplot(result_LTS_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = " ",
        ylab = " ",
        xaxt = "s",
        names.arg = x_labels,
        col = colors_3,
        horiz = FALSE
)
abline(h = quantile(result_LTS_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=2)
abline(h = quantile(result_LTS_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=1)
abline(h = quantile(result_LTS_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=1)
title(outer=outer,adj=adj,main="LTS",cex.main=cex,col="black",font=2,line=line)



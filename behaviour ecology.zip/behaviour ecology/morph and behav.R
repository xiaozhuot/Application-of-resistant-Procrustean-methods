library(gllvm)
library(vegan)
library("FactoMineR")
library("factoextra")
library(fBasics)#take trace
library(combinat)#permutation
library("readxl")
library(gtools) #for combination()
library(expm)
library(IMIFA)
library(ggplot2)
library(plotrix)
library(Cairo)
library(ape)


source("resistant_codes_LMS_LTS.txt")
source("test of permutation.txt")

morph_dat = read.csv("morphlogical measurements.csv")
perform_dat = read.csv("performance measurements.csv")
behav_dat = read.csv("behaviour measurements.csv")
eco_dat = read.csv("ecological measurements.csv")

rownames(morph_dat) = morph_dat[,1]
morph_dat = morph_dat[,-1]

rownames(behav_dat) = behav_dat[,1]
behav_dat = behav_dat[,-1]

morph_dat_clean = morph_dat[-c(2,6),]
behav_dat_clean = behav_dat[-c(2,6),]

morph_transformed = log(morph_dat_clean)  # Natural log (ln)

arcsin_transform <- function(p) {
  asin(sqrt(p))
}
behav_transformed <- behav_dat_clean  # Create it first!

# Now apply transformations
proportion_vars <- c("display_rate", "walk_proportion", "run_proportion", "jump_proportion")
for (var in proportion_vars) {
  if (var %in% names(behav_transformed)) {
    behav_transformed[[var]] <- arcsin_transform(behav_transformed[[var]])
  }
}

continuous_vars <- c("moves_per_min", "jump_in_nature_cm")
for (var in continuous_vars) {
  if (var %in% names(behav_transformed)) {
    behav_transformed[[var]] <- log(behav_transformed[[var]])
  }
}

# Check the results
head(morph_transformed)
head(behav_transformed)


##PCA scale=true is using correlation matrix
morph_pca = prcomp(morph_transformed, scale. = TRUE)
summary(morph_pca)
morph_scores = morph_pca$x[,1:3]

behav_pca = prcomp(behav_transformed, scale. = TRUE)
summary(behav_pca)
behav_scores = behav_pca$x[,1:3]


par(mfrow=c(1,2), mar=c(4,5,1.5,2), oma=c(1,0,0,2), cex.axis = 1.2, las=2,cex.lab = 1.5)
outer = FALSE
line = 3
cex = 1.5
adj  = 0.5

plot(morph_scores[, 1], morph_scores[, 2],  # First two principal components
     xlab = paste0("PC1 (", round(summary(morph_pca)$importance[2, 1] * 100, 2), "%)"),
     ylab = paste0("PC2 (", round(summary(morph_pca)$importance[2, 2] * 100, 2), "%)"),
     xlim = c(-6.5,4),
     ylim = c(-1.2,1.2),
     main = "Morph",
     pch = 19, col = "black")
text(morph_scores[, 1], morph_scores[, 2], labels = rownames(morph_scores), pos = 3, cex = 0.8)
abline(h = 0, v = 0, col = "gray", lty = 2)

plot(behav_scores[, 1], behav_scores[, 2],  # First two principal components
     xlab = paste0("PC1 (", round(summary(behav_pca)$importance[2, 1] * 100, 2), "%)"),
     ylab = paste0("PC2 (", round(summary(behav_pca)$importance[2, 2] * 100, 2), "%)"),
     xlim = c(-3,3),
     ylim = c(-2.2,2.2),
     main = "Behav",
     pch = 19, col = "black")
text(behav_scores[, 1], behav_scores[, 2], labels = rownames(behav_scores), pos = 3, cex = 0.8)
abline(h = 0, v = 0, col = "gray", lty = 2)




P_mat = morph_scores
Q_mat = behav_scores


##procrustes##
result_proc = Procrustes_fun(P_mat,Q_mat)
procrustes_obj = result_proc$s
res_procrustes = Procrustes_permute(P_mat,Q_mat,999,procrustes_obj)
sum(res_procrustes$converge_vec)
res_procrustes$p_value

vector_1 = rep(1,dim(P_mat)[1])
result_procrustes_residual = 
  Q_mat - result_proc$scal*(P_mat)%*%(result_proc$rot)-vector_1%*%t(result_proc$trans_P)
# mean_mad_procrustes = mean(apply(result_procrustes_residual,2,mad,constant=1))
# sd_procrustes_residual = result_procrustes_residual/mean_mad_procrustes
# sd_procrustes_residual_dis = sqrt(rowSums(sd_procrustes_residual*sd_procrustes_residual))
# barplot(sd_procrustes_residual_dis,main="Procrustes",las = 2, cex.names = 0.65)

procrustes_residual_dis = sqrt(rowSums(result_procrustes_residual*result_procrustes_residual))
barplot(procrustes_residual_dis,las = 2,main="Procrustes",cex.names = 0.65)

# sd_result_procrustes_residual = result_procrustes_residual/sd(result_procrustes_residual)
# plot(sd_result_procrustes_residual[,2])
# abline(h = 3, col="red", lwd=1.4, lty=3)
# abline(h = -3, col="red", lwd=1.4, lty=3)

#############################ILMS (improved LMS)
result_ILMS= LMS_LTS_estimator(P_mat,Q_mat,0,s_l_LMS,s_u_LMS)
ILMS_obj = result_ILMS$s
res_ILMS = ILMS_permute(P_mat,Q_mat,999,ILMS_obj)
sum(res_ILMS$converge_vec)
res_ILMS$p_value


result_ILMS_residual = 
  Q_mat - result_ILMS$scal*(P_mat)%*%(result_ILMS$rot)-vector_1%*%t(result_ILMS$trans_P)
result_ILMS_residual_dis = sqrt(rowSums(result_ILMS_residual*result_ILMS_residual))
barplot(result_ILMS_residual_dis,las = 1,
        main="ILMS",cex.names = 0.65)

ILMS_trans_P = result_ILMS$scal*(P_mat)%*%(result_ILMS$rot)+vector_1%*%t(result_ILMS$trans_P)

ILMS_pvalue = res_ILMS$p_value
save(result_ILMS_residual_dis,file = "dim of three ILMS residual distance.RData")


#########residual plot add median and quartiles

x_labels = rownames(Q_mat)
# highlight_names_ILMS = names(result_ILMS_residual_dis[outliers_ILMS])
# colors_2 = ifelse(x_labels %in% highlight_names_ILMS, "darkred", "darkgray") 
# 

par(mfrow=c(2,1),mar=c(4,2,1,1),oma=c(0,3,1,3),cex.axis = 1.3)
outer = FALSE
line = -0.01
cex = 1.5
adj  = 0.001
barplot(result_ILMS_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = " ",
        ylab = " ",
        xaxt = "s",
        names.arg = FALSE,
        #col = colors_2,
        horiz = FALSE
)
abline(h = quantile(result_ILMS_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(result_ILMS_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(result_ILMS_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="ILMS",cex.main=cex,col="black",font=2,line=line)

bp_PA =barplot(procrustes_residual_dis,cex.names = 1.3,
               main = " ",
               xlab = "",
               ylab = " ",
               xaxt = "s",
               names.arg = FALSE,
               las =2,
               #col = colors_1,
               space = 0.5,
               horiz = FALSE)
abline(h = quantile(procrustes_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(procrustes_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(procrustes_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="PA",cex.main=cex,col="black",font=2,line=line)
text(x = bp_PA, y = par("usr")[3] - 0.1,  # just below the bars
     labels = x_labels, srt = 45, xpd = TRUE,
     adj = 1, cex = 1)






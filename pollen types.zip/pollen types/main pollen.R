library(gllvm)
library(vegan)
library(FactoMineR)
library(factoextra)
library(fBasics)#take trace
library(combinat)#permutation
library(readxl)
library(gtools) #for combination()
#library("pcaL1") robust pca l1
library(ggplot2)
library(ggrepel)  # for avoiding overlapping labels
library(patchwork)


source("resistant_codes_LMS_LTS.txt")
#source("resistant_codes_LMS_LTS_save_memory.txt")
source("test of permutation.txt")


graze_data = read.csv("pollen with graze.csv")
no_graze_data = read.csv("pollen no graze.csv")
dim(graze_data)
dim(no_graze_data)
colnames(graze_data)[trimws(colnames(graze_data)) == "Aster"] <- "Aster.T"


pollen_with_graze = graze_data[,-c(2,3)]
rownames(pollen_with_graze) = pollen_with_graze[,1]
pollen_with_graze = pollen_with_graze[,-1]

pollen_no_graze = no_graze_data[,-c(2,3)] 
rownames(pollen_no_graze) = pollen_no_graze[,1]
pollen_no_graze = pollen_no_graze[,-1]

pollen_combined = rbind(pollen_with_graze, pollen_no_graze)

taxa_keep_combined <- apply(pollen_combined, 2, function(x) {
  cond1 <- sum(x > 0) >= 3      # present in ≥3 samples total
  cond2 <- max(x) >= 3          # max abundance ≥3%
  cond1 & cond2
})

pollen_with_graze_new <- pollen_with_graze[, taxa_keep_combined]
pollen_no_graze_new <- pollen_no_graze[, taxa_keep_combined]


##PCA percentage
#use prcomp instead of princomp because varaibles are more than observations
pollen_with_graze_hellinger <- decostand(pollen_with_graze_new, method = "hellinger")
PCA_pollen_with_graze = rda(pollen_with_graze_hellinger) #sqrt and hellinger are basivally the same
summary(PCA_pollen_with_graze)
permu_pollen_with_graze = scores(PCA_pollen_with_graze, display = "species", choices = 1:2)
sites_with_graze = scores(PCA_pollen_with_graze, display = "sites", choices = 1:2)

pollen_no_graze_hellinger <- decostand(pollen_no_graze_new, method = "hellinger")
PCA_pollen_no_graze = rda(pollen_no_graze_hellinger)
summary(PCA_pollen_no_graze)
#permu_pollen_no_graze = PCA_pollen_no_graze$x[,1:2]
permu_pollen_no_graze = scores(PCA_pollen_no_graze, display = "species", choices = 1:2)
sites_no_graze = scores(PCA_pollen_no_graze, display = "sites", choices = 1:2)



species_labels = rownames(permu_pollen_with_graze)
species_labels[c(6,22)] <- c("Poaceae(<36)", "Poaceae(>36)")

# Prepare data for ggplot with graze
pca_data_with_graze <- data.frame(
  PC1 = sites_with_graze[, 1],
  PC2 = sites_with_graze[, 2]
)

species_data_with_graze <- data.frame(
  PC1 = permu_pollen_with_graze[, 1],
  PC2 = permu_pollen_with_graze[, 2],
  Species = species_labels
)

# Calculate variance explained
var_exp_with_graze <- round(100 * PCA_pollen_with_graze$CA$eig / sum(PCA_pollen_with_graze$CA$eig), 1)


# Prepare data for ggplot no graze
pca_data_no_graze <- data.frame(
  PC1 = sites_no_graze[, 1],
  PC2 = sites_no_graze[, 2]
)

species_data_no_graze <- data.frame(
  PC1 = permu_pollen_no_graze[, 1],
  PC2 = permu_pollen_no_graze[, 2],
  Species = species_labels
)

# Calculate variance explained
var_exp_no_graze <- round(100 * PCA_pollen_no_graze$CA$eig / sum(PCA_pollen_no_graze$CA$eig), 1)


##############plot
# Grazed plot
plot_grazed <- ggplot() +
  geom_point(data = pca_data_with_graze, aes(x = PC1, y = PC2), 
             size = 2, alpha = 0.7) +
  geom_segment(data = species_data_with_graze,
               aes(x = 0, y = 0, xend = PC1 * 0.8, yend = PC2 * 0.8),
               arrow = arrow(length = unit(0.2, "cm")),
               color = "black", alpha = 0.6) +
  geom_text_repel(data = species_data_with_graze,
                  aes(x = PC1 * 0.9, y = PC2 * 0.9, label = Species),
                  size = 2.5, color = "black", max.overlaps = 20) +
  geom_hline(yintercept = 0, linetype = "dashed", alpha = 0.5) +
  geom_vline(xintercept = 0, linetype = "dashed", alpha = 0.5) +
  labs(
    title = "Grazed sites",
    x = paste0("PC1 (", var_exp_with_graze[1], "%)"),
    y = paste0("PC2 (", var_exp_with_graze[2], "%)")
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    panel.grid = element_blank(),
    axis.text = element_text(size = 12),     # tick numbers
    axis.title = element_text(size = 14),
    axis.title.x = element_text(margin = margin(t = 12)),  # space above x label
    axis.title.y = element_text(margin = margin(r = 12)),# axis labels (PC1, PC2)
    axis.line = element_line(color = "black", linewidth = 0.8)# add x y borders
  )+ xlim(-0.65,1) + ylim(-0.7, 0.9)

# Ungrazed plot
plot_no_graze <- ggplot() +
  geom_point(data = pca_data_no_graze, aes(x = PC1, y = PC2), 
             size = 2, alpha = 0.7) +
  geom_segment(data = species_data_no_graze,
               aes(x = 0, y = 0, xend = PC1 * 0.8, yend = PC2 * 0.8),
               arrow = arrow(length = unit(0.2, "cm")),
               color = "black", alpha = 0.6) +
  geom_text_repel(data = species_data_no_graze,
                  aes(x = PC1 * 0.9, y = PC2 * 0.9, label = Species),
                  size = 2.5, color = "black", max.overlaps = 20) +
  geom_hline(yintercept = 0, linetype = "dashed", alpha = 0.5) +
  geom_vline(xintercept = 0, linetype = "dashed", alpha = 0.5) +
  labs(
    title = "Ungrazed sites",
    x = paste0("PC1 (", var_exp_no_graze[1], "%)"),
    y = paste0("PC2 (", var_exp_no_graze[2], "%)")
  ) +
  theme_minimal() +
  theme(
    plot.title = element_text(hjust = 0.5, face = "bold", size = 14),
    panel.grid = element_blank(),
    axis.text = element_text(size = 12),     # tick numbers
    axis.title = element_text(size = 14),
    axis.title.x = element_text(margin = margin(t = 12)),  # space above x label
    axis.title.y = element_text(margin = margin(r = 12)),# axis labels (PC1, PC2)
    axis.line = element_line(color = "black", linewidth = 0.8) 
  )+ xlim(-0.65,1) + ylim(-0.7, 0.9)

combined_plot <- plot_grazed + plot_no_graze + plot_layout(ncol = 2) &
  theme(panel.spacing = unit(2, "cm"))
combined_plot


P_mat = permu_pollen_with_graze
Q_mat = permu_pollen_no_graze

# P_mat = permu_pollen_no_graze
# Q_mat = permu_pollen_with_graze

##procrustes##
result_proc = Procrustes_fun(P_mat,Q_mat)
procrustes_obj = result_proc$s
res_procrustes = Procrustes_permute(P_mat,Q_mat,999,procrustes_obj)
sum(res_procrustes$converge_vec)
res_procrustes$p_value

vector_1 = rep(1,dim(P_mat)[1])
result_procrustes_residual = 
  Q_mat - result_proc$scal*(P_mat)%*%(result_proc$rot)-vector_1%*%t(result_proc$trans_P)
# mean_mad_procrustes = mean(apply(result_procrustes_residual,2,mad,constant=1))
# sd_procrustes_residual = result_procrustes_residual/mean_mad_procrustes
# sd_procrustes_residual_dis = sqrt(rowSums(sd_procrustes_residual*sd_procrustes_residual))
# barplot(sd_procrustes_residual_dis,main="Procrustes",las = 2, cex.names = 0.65)

procrustes_residual_dis = sqrt(rowSums(result_procrustes_residual*result_procrustes_residual))
barplot(procrustes_residual_dis,las = 2,main="Procrustes",cex.names = 0.65)


###########################################################################
result_ILMS= LMS_LTS_estimator(P_mat,Q_mat,0,s_l_LMS,s_u_LMS)
#result_ILMS= LMS_LTS_estimator(P_mat,Q_mat,10000,s_l_LMS,s_u_LMS)used for permutation
ILMS_obj = result_ILMS$s
res_ILMS = ILMS_permute(P_mat,Q_mat,999,ILMS_obj)
ILMS_p_value = res_ILMS$p_value
save(ILMS_p_value, file = "ILMS_p_value.RData")

vector_1 = rep(1,dim(P_mat)[1])
result_ILMS_residual =
  Q_mat - result_ILMS$scal*(P_mat)%*%(result_ILMS$rot)-vector_1%*%t(result_ILMS$trans_P)
result_ILMS_residual_dis = sqrt(rowSums(result_ILMS_residual*result_ILMS_residual))
barplot(result_ILMS_residual_dis,las = 2,main="ILMS",cex.names = 0.65)

###########################################################################






#########

x_labels = rownames(P_mat)
x_labels[c(6,22)] <- c("Poaceae(<36)", "Poaceae(>36)")

# colors <- rep("darkgray", length(result_S_residual_dis)) # Default color
# colors[9] <- "darkred" # Highlight the 9th bar with a different color


par(mfrow=c(2,1),mar=c(5,2,2,1),oma=c(0,3,1,3),cex.axis = 1.3)
outer = FALSE
line = -0.01
cex = 1.5
adj  = 0.001
barplot(result_ILMS_residual_dis,cex.names = 1.3,
                  main = " ",
                  xlab = " ",
                  ylab = " ",
                  xaxt = "s",
                  names.arg = FALSE,
                  #col = colors_2,
                  horiz = FALSE
)
abline(h = quantile(result_ILMS_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(result_ILMS_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(result_ILMS_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="ILMS",cex.main=cex,col="black",font=2,line=line)

bp_PA =barplot(procrustes_residual_dis,cex.names = 1.3,
        main = " ",
        xlab = "",
        ylab = " ",
        xaxt = "s",
        names.arg = FALSE,
        las =2,
        #col = colors_1,
        space = 0.5,
        horiz = FALSE)
abline(h = quantile(procrustes_residual_dis, 0.5), col = "darkblue", lty = 1,lwd=3)
abline(h = quantile(procrustes_residual_dis, 0.25), col = "darkblue", lty = 2,lwd=2)
abline(h = quantile(procrustes_residual_dis, 0.75), col = "darkblue", lty = 2,lwd=2)
title(outer=outer,adj=adj,main="PA",cex.main=cex,col="black",font=2,line=line)
text(x = bp_PA, y = par("usr")[3] - 0.01,  # just below the bars
     labels = x_labels, srt = 45, xpd = TRUE,
     adj = 1, cex = 1)


